const keyMirror = require("keymirror");

export const UserDetailsConstants = keyMirror({
  FETCH_USER_DETAILS: undefined
});
