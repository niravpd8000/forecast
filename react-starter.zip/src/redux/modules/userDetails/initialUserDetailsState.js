export const initialUserDetailsState = () => ({
  fetchUserDetailsLoading: false,
  fetchUserDetailsFailure: false,
  fetchUserDetailsLoaded: false,
  details: null
});
